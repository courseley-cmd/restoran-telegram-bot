# Telegram Bot for Restaurant

Gets booking requests from Tilda, sends buttons to Telegram, and logs to Google Sheets.